const excelFileInput = document.getElementById("excelFile");
const companyRowSelect = document.getElementById("companyRow");
const companyColumnSelect = document.getElementById("companyColumn");
const submitButton = document.getElementById("submitButton");
const downloadButton = document.getElementById("downloadButton");
const newCompanyInput = document.getElementById("newCompany");
const addCompanyButton = document.getElementById("addCompanyButton");
let workbook,
  worksheet,
  companyList = [];

// Function to read and parse the uploaded Excel file
excelFileInput.addEventListener("change", function (event) {
  const file = event.target.files[0];
  const reader = new FileReader();

  reader.onload = function (event) {
    const data = new Uint8Array(event.target.result);
    workbook = XLSX.read(data, { type: "array" });
    // console.log(workbook)

    const firstSheetName = workbook.SheetNames[0];
    worksheet = workbook.Sheets[firstSheetName];
    // console.log(worksheet)

    // Get companies from the first row and column
    const headers = XLSX.utils.sheet_to_json(worksheet, { header: 1 })[0]; // Get first row (header)
    companyList = headers;

    console.log(companyList);

    // Populate both select boxes
    populateSelect(companyRowSelect, headers);
    populateSelect(companyColumnSelect, headers);
  };

  reader.readAsArrayBuffer(file);
});

// Function to populate dropdowns
function populateSelect(selectElement, options) {
  selectElement.innerHTML =
    '<option value="" disabled selected>Select a company</option>';
  options.forEach((option) => {
    const opt = document.createElement("option");
    opt.value = option;
    opt.textContent = option;
    selectElement.appendChild(opt);
  });
}

// Prevent the same company from being selected in both dropdowns
companyRowSelect.addEventListener("change", disableSameCompany);
companyColumnSelect.addEventListener("change", disableSameCompany);

function disableSameCompany() {
  const rowCompany = companyRowSelect.value;
  const columnCompany = companyColumnSelect.value;

  if (rowCompany === columnCompany) {
    alert("You cannot select the same company in both row and column.");
    companyColumnSelect.value = ""; // Reset the column dropdown if the same is selected
  }
}

// Add new company to both row and column
function addCompany() {
  const newCompany = newCompanyInput.value.trim();

  if (!newCompany) {
    alert("Please enter a company name.");
    return;
  }

  // Check if the company already exists
  if (companyList.includes(newCompany)) {
    alert("This company already exists.");
    return;
  }

  // Add the new company to the companyList
  companyList.push(newCompany);

  // Determine the new index for the row and column
  const newIndex = companyList.length - 1;

  // Ensure that the worksheet has enough rows and columns
  //   const currentRowCount = XLSX.utils.sheet_to_json(worksheet, {
  //     header: 1,
  //   }).length;
  //   const currentColCount = companyList.length; // This should reflect the total companies now

  //   // Update worksheet to ensure it can accommodate new row/column
  //   if (newIndex >= currentRowCount) {
  //     // If adding a new row, ensure enough rows exist
  //     for (let i = currentRowCount; i <= newIndex; i++) {
  //       worksheet[XLSX.utils.encode_cell({ r: i, c: 0 })] = { v: "", t: "s" }; // Row header
  //     }
  //   }

  //   if (newIndex >= currentColCount) {
  //     // If adding a new column, ensure enough columns exist
  //     for (let i = currentColCount; i <= newIndex; i++) {
  //       worksheet[XLSX.utils.encode_cell({ r: 0, c: i })] = { v: "", t: "s" }; // Column header
  //     }
  //   }

  // Set the new company name in the first column (row header)
  worksheet[XLSX.utils.encode_cell({ r: newIndex, c: 0 })] = {
    v: newCompany,
    t: "s",
  };

  // Set the new company name in the first row (column header)
  worksheet[XLSX.utils.encode_cell({ r: 0, c: newIndex })] = {
    v: newCompany,
    t: "s",
  };

  // Initialize cells for the new row and column to empty
  //   for (let i = 1; i <= newIndex; i++) {
  //     worksheet[XLSX.utils.encode_cell({ r: i, c: newIndex })] = {
  //       v: "",
  //       t: "s",
  //     };
  //     worksheet[XLSX.utils.encode_cell({ r: newIndex, c: i })] = {
  //       v: "",
  //       t: "s",
  //     };
  //   }

  // Set the diagonal cell to "-"
  worksheet[XLSX.utils.encode_cell({ r: newIndex, c: newIndex })] = {
    v: "-",
    t: "s",
  };

  // Populate both select boxes again
  populateSelect(companyRowSelect, companyList);
  populateSelect(companyColumnSelect, companyList);

  // Clear the input field
  newCompanyInput.value = "";
}

addCompanyButton.addEventListener("click", addCompany);

// Store the entered value in the corresponding cell of the Excel sheet
submitButton.addEventListener("click", function () {
  const rowCompany = companyRowSelect.value;
  const columnCompany = companyColumnSelect.value;
  const amount = document.getElementById("amount").value;

  if (!rowCompany || !columnCompany || !amount) {
    alert("Please select both companies and enter an amount.");
    return;
  }

  if (rowCompany === columnCompany) {
    alert("You cannot map a company to itself.");
    return;
  }

  // Find row and column indices of the selected companies
  const rowIndex = companyList.indexOf(rowCompany); // Add 1 because rows start after headers
  const columnIndex = companyList.indexOf(columnCompany); // Column index corresponds to the header

  console.log(rowIndex, columnIndex);

  // Make sure row and column are valid
  if (rowIndex < 0 || columnIndex < 0) {
    alert("Invalid selection, please check the company names.");
    return;
  }

  // Set the amount in the correct cell in the Excel sheet
  const cellAddress = XLSX.utils.encode_cell({
    r: rowIndex,
    c: columnIndex,
  });
  worksheet[cellAddress] = { v: amount, t: "n" };

  // Clear inputs after submission
  companyRowSelect.value = "";
  companyColumnSelect.value = "";
  document.getElementById("amount").value = "";
});

// Download the updated Excel file when "Download" button is clicked
downloadButton.addEventListener("click", function () {
  const newWorkbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(newWorkbook, worksheet, "Sheet1");
  XLSX.writeFile(newWorkbook, "UpdatedCompanyMatrix.xlsx");
});
